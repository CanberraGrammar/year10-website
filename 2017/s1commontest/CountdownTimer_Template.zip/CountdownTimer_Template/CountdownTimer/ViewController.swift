//
//  ViewController.swift
//  CountdownTimer
//

import UIKit

class ViewController: UIViewController {
    
    // This function is called when the app launches and the view appears on screen
    override func viewDidLoad() {
        
        // Call super
        super.viewDidLoad()
        
        // Create NSDate for 31 December at 23:59:59
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm:ss"
        let newYearDateTime = formatter.date(from: "2017/12/31 23:59:59")
        
        // Determine the number of seconds between now and newYearDate and store in interval
        let dateTimeRightNow = Date()
        var interval = Int(newYearDateTime!.timeIntervalSince(dateTimeRightNow))
        
    }
    
}
