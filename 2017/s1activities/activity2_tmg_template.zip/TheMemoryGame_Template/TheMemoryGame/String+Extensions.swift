//
//  String+Extensions.swift
//  TheMemoryGame
//

import UIKit

extension String {
 
    // --------------------------------------------------------------------
    // * Returns a symbol (in a String) for a valid index between 0...299 *
    // --------------------------------------------------------------------

    static func symbolForIndex(_ index: Int) -> String? {
        var index = index
        
        // Check whether a valid index has been provided
        guard index >= 0 && index <= 299 else {
            
            // Crash the program out
            assert(false, "\n\nHey there, the index which has been provided to the String.iconForIndex method is outside of the allowable range of 0 to 299 inclusive. Maybe check what value is being passed in by using a print() statement to print it out to the console? This might help track down the cause of the issue. Happy debugging! - MPP :)\n\n")
            
            // Break out
            return nil
            
        }
        
        // Valid range of hexadecimal values for the font is 0xE000...0xE12B which is 57344...57643
        // So, add 57344 onto the index
        index = index + 57344
        
        // Get the symbol unicode character value
        let char: UniChar = UInt16(index)
        
        // Return the string
        return String(format: "%C", char)
        
    }
    
}
