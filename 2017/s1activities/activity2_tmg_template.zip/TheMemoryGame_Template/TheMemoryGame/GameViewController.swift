//
//  ViewController.swift
//  TheMemoryGame
//




// **** STUDENT DECLARATION GOES HERE ****




import UIKit

class GameViewController: UIViewController {

    // Outlets
    @IBOutlet weak var buttonZero: UIButton!
    @IBOutlet weak var buttonOne: UIButton!
    @IBOutlet weak var buttonTwo: UIButton!
    @IBOutlet weak var buttonThree: UIButton!
    @IBOutlet weak var buttonFour: UIButton!
    @IBOutlet weak var buttonFive: UIButton!
    @IBOutlet weak var buttonSix: UIButton!
    @IBOutlet weak var buttonSeven: UIButton!
    @IBOutlet weak var buttonEight: UIButton!
    @IBOutlet weak var buttonNine: UIButton!
    @IBOutlet weak var buttonTen: UIButton!
    @IBOutlet weak var buttonEleven: UIButton!
    @IBOutlet weak var buttonTwelve: UIButton!
    @IBOutlet weak var buttonThirteen: UIButton!
    @IBOutlet weak var buttonFourteen: UIButton!
    @IBOutlet weak var buttonFifteen: UIButton!
    
    @IBOutlet weak var playGameButton: UIButton!
    @IBOutlet weak var guessesLabel: UILabel!
    
    // Array to store all the button IBOutlets for ease of access
    var buttonArray = [UIButton]()
    
    
    // MARK: - view lifecycle
    
    
    // ------------------------------------------------------------
    // * Called after the controller's view is loaded into memory *
    // ------------------------------------------------------------

    override func viewDidLoad() {
        
        // Call super
        super.viewDidLoad()
        
        // Put all the button IBOutlets into the buttonArray
        self.buttonArray.append(buttonZero)
        self.buttonArray.append(buttonOne)
        self.buttonArray.append(buttonTwo)
        self.buttonArray.append(buttonThree)
        self.buttonArray.append(buttonFour)
        self.buttonArray.append(buttonFive)
        self.buttonArray.append(buttonSix)
        self.buttonArray.append(buttonSeven)
        self.buttonArray.append(buttonEight)
        self.buttonArray.append(buttonNine)
        self.buttonArray.append(buttonTen)
        self.buttonArray.append(buttonEleven)
        self.buttonArray.append(buttonTwelve)
        self.buttonArray.append(buttonThirteen)
        self.buttonArray.append(buttonFourteen)
        self.buttonArray.append(buttonFifteen)

        // Setup the UI
        for button in self.buttonArray {
            
            // Set the font on all the buttons
            button.titleLabel!.font = UIFont(name: "Metrize-Icons", size: 58)
            button.setTitleColor(UIColor.darkGray, for: UIControlState())
            
            // Set all the buttons with empty circles (character code 246) and disable them
            button.setTitle(String.symbolForIndex(246), for: UIControlState())
            button.isEnabled = false
            
        }
        
    }

    
    // --------------------------------------------------------------------------------------
    // * Specifies whether the view controller prefers the status bar to be hidden or shown *
    // --------------------------------------------------------------------------------------
    
    override var prefersStatusBarHidden : Bool {
        
        // Hide the status bar
        return true
        
    }
    
    
    // MARK: - IBActions
    
    
    // -------------------------------------------------
    // * Called when one of the icon buttons is tapped *
    // -------------------------------------------------

    @IBAction func symbolButtonTapped(_ sender: UIButton) {
        
        // Debug - remove me
        print("Symbol Button Tapped")
        
        // Each UIButton is assigned a tag from 0 to 15 inclusive. Accessing sender.tag allows you to determine which
        // button was tapped. For debug and testing you can print out sender.tag to see this in actino.
        print(sender.tag)
        
    }
    
    
    // ----------------------------------------------
    // * Called when the Play Game button is tapped *
    // ----------------------------------------------
    
    @IBAction func playGameButtonTapped(_ sender: UIButton) {
        
        // Debug - remove me
        print("Play Game Button Tapped")
        
    }
    
}
