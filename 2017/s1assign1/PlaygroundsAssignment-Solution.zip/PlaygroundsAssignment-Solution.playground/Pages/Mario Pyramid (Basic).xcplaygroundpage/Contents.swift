/*:
 
 # Year 10 IST - Assignment One
 
 ### Mario Pyramid (Basic)
 
 In Nintendo’s Super Mario Brothers, Mario needs to climb a half-pyramid to jump and reach a flag pole - as shown in this screenshot:
 
 ![Mario Half-Pyramid](mario.png)
 
 Write a program which will print, to the console, a half-pyramid of the height specified in the `height` constant.
 
 For example, if the `height` is equal to `5` then this should be printed:
 
 ````
     ##
    ###
   ####
  #####
 ######
 ````
 
 You can assume that the value of `height` will always be a value >= `1`.
 
 P.S. The height of the half-pyramid in the screenshot from Super Mario Brothers above is 8.
 */
// SOLUTION CREDIT: Filippo F. (IT1002)

let height = 5;

for i in 0...height-1 {
    
    // The first nested loop prints the required number of spaces before the hash # symbol
    for j in 0...height - 1 - i {
        // Print without a new line character at the end
        print(" ", terminator: "")
    }
    
    // The second nested loop prints the number of hash # symbols needed for the row
    for k in 0...i + 1 {
        // Print without a new line character at the end
        print("#", terminator: "")
    }
    
    // Print a new line
    print("")
    
}
//: ---
//: [Next](@next)
