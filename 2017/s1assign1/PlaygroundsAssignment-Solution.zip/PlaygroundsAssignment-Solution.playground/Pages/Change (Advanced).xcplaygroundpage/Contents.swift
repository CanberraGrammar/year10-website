/*:
 
 # Year 10 IST - Assignment One
 
 ### Change (Advanced)
 
 You need to develop a program which determines the amount of change for a purchase, given a purchase amount and an amount of cash tendered.
 
 There are two constants to hold these pieces of data: `purchaseAmount` and `cashTendered`.
 
 However, this program is being used in a country called Nailartsua which has quite a strange (and somewhat arbitrary) denomination of currency. Valid denominations in coins are 1 cent, 15 cents, and 25 cents. The valid denominations in bills are $10, $30, and $40.
 
 The output of the program should be the number of Nailartsua coins and bills that need to be given to the customer for the change.
 
 For example, the output for `purchaseAmount` = `19.70` and `cashTendered` = `20.00` would be:
 
 ````
 $40 x 0
 $20 x 0
 $10 x 0
 $0.25 x 0
 $0.15 x 2
 $0.01 x 0
 ````
 
 The program should always dispense the least quantity of money to make up the required amount of change. For example, it should dispense 1x $20 note rather than 2x $10 notes.
 
 The program should print the message "Insufficient cash tendered" if the `purchaseAmount` is greater than the `cashTendered` amount.
 
 You don't need to worry about handling invalid inputs (e.g. `4a.38`). You can assume that a valid amount of money will always be input into the program.
 
 **Tip:** Test your algorithm for change amounts like $60.30. Your algorithm might determine the change as `1x $40, 2x $10, 1x $0.25, 5x $0.01` whereas the optimal solution is `2x $30, 2x $0.15`.
 
 */
// SOLUTION CREDIT: Jack C. (IT1001)

import Foundation

let purchaseAmount = 59.70
let cashTendered = 60.00

let currencyDenominations = [40.0, 30.0, 10.0, 0.25, 0.15, 0.01]

// Round to 3 dp because of floating point numbers
let totalChangeToGive = round(1000 * (cashTendered - purchaseAmount)) / 1000

// Dictionary to store final value
var pieceNums = [String: Int]()

// Set up dictionary and start main loop
func start(){
    
    for i in currencyDenominations{
        pieceNums[String(format: "%g", i)] = 0
    }
    
    findChange()
    
}

//Start with one cent: make the change remaining divisible by any of the upper denominations (check downwards) by taking away current denomination
func findChange(){
    
    var changeToGive = totalChangeToGive
    var readyToMove = false
    for denom in currencyDenominations.reversed(){
        
        // First, need to check if any denom above is EXACTLY a multiple of change. If so, move for loop to that one. If not, subtract a denom. Then, check again.
        
        while(changeToGive > 0 && !readyToMove){
            
            for chkDenom in currencyDenominations{
                
                if(chkDenom == denom){
                    break
                }
                else {
                    if(round(changeToGive.remainder(dividingBy: chkDenom)*100)/100 == 0.0){
                        readyToMove = true
                    }
                }
            }
            
            if(readyToMove){
                readyToMove = false
                break
            }
            else {
                changeToGive -= denom
                changeToGive = round(changeToGive*100)/100
                // Rounding to cope for innacuracies
                pieceNums[String(format: "%g", denom)]! += 1
            }
            
        }
        
    }
}

if (cashTendered >= purchaseAmount) {
    
    start()
    
    // Print out with correct formatting
    for i in currencyDenominations{
        print(String(format: "$%g", i) + " x \(pieceNums[String(format: "%g", i)]!)")
    }
    
}

else {
    print("Insufficient cash tendered")
}
//: ---
//: [Previous](@previous) | [Next](@next)
