/*:
 
 # Year 10 IST - Assignment One
 
 ### Spiral in a Box (Advanced)
 
 Write a program which will print, to the console, a spiral inside of a box based upon a size specified in the `size` constant.
 
 For example, if the `size` is `4` then this should be printed:
 
 ![Spiral Size 4](spiral4.png)
 
 ...or if the `size` is `5` then this should be printed:
 
  ![Spiral Size 5](spiral5.png)
 
 The above are just examples – your program should be able to print any sized box (we will be varying the box size when testing your program to ensure that it works correctly). However, you can assume that the input size for the box will always be greater than 1.

 A sample project, allowing you to see a working example, is available at: [http://www.cgscomputing.com/year10/spiral/sample.php?size=5](http://www.cgscomputing.com/year10/spiral/sample.php?size=5) (change the `size` argument to see different sized spirals). This will be very useful so you can check that the spirals you are drawing are correct.
 
If an invalid value is entered for the size (i.e. not a number greater than 1) then nothing should print.
*/
// SOLUTION CREDIT: Jack C. (IT1001)
// Note, this is a recursive solution to the problem

// Need foundation for some of the functions used below (such as ceil)
import Foundation

let size = 5;

let horizontal = "- "
let vertical = "| "
let diagFore = "/ "
let diagBack = "\\ "

var currentLine = 0

// Varible to know when to switch from the upper half of the box (upperLine) to the lower half (lowerLine)
let halfLine = Int(ceil(Double(size)/2.0)) - 1

// Function to print multiple of the same characters
func returnMultipleChars(_ char: String, _ num: Int) -> String {
    
    var returnString = ""
    
    if (num <= 0){
        return ""
    }
        
    else {
        for _ in 0...(num - 1) {
            returnString += char
        }
    }
    
    return returnString
}

// Upper half of the box
func upperLine(_ line: Int) {
    
    // Line will be equal to the number of non-horizontals that begin the line
    var finalLine = ""
    
    // Add verticals and diag before the horizontals
    finalLine += returnMultipleChars(vertical, line - 1)
    
    // Only add it if it's not the first line
    if (line >= 1) { finalLine += diagFore }
    
    // Horizontals
    finalLine += returnMultipleChars(horizontal, (size - (line*2 + 1)))
    
    // Add diag
    finalLine += diagBack
    finalLine += returnMultipleChars(vertical, line)
    
    print(finalLine)
    
    // Transition to the next half
    if (currentLine >= halfLine) {
        if (size % 2 == 0) {
            currentLine += 1
        }
        lowerLine(currentLine)
    }
    
    else {
        currentLine += 1
        
        // Recursively call upperLine
        upperLine(currentLine)
    }
    
}

// Lower half of the box
func lowerLine(_ line: Int) {
    
    // Line will be equal to number of non horizontals on either side
    var finalLine = ""
    
    // Add verticals and diags
    finalLine += returnMultipleChars(vertical, line - 1)
    finalLine += diagBack
    
    // Horizontals
    finalLine += returnMultipleChars(horizontal, size - (line*2))
    
    // Diag and verticals
    finalLine += diagFore
    finalLine += returnMultipleChars(vertical, line - 1)
    
    print(finalLine)
    
    currentLine -= 1
    
    if(currentLine > 0){
        // Recursively call lowerLine
        lowerLine(currentLine)
    }
    
}

// Start the recursion with upperLine
if (size > 1) {
    upperLine(currentLine)
}
//: ---
//: [Previous](@previous) | [Next](@next)
