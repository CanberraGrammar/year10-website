/*:
 
 # Year 10 IST - Assignment One
 
 ### Check Digit (Basic)
 
 Universal product codes (UPC) are a 13-digit number found underneath product barcodes. The last digit is a check digit which is used to ensure that the UPC is valid. It consists of a single digit which is computed (or derived) from the other 12 digits in the sequence. Using the check digit it is possible to detect simple errors in a series of numbers, such as typos, to make sure that the UPC is valid. Take the following example of how a check digit is determined for UPC barcodes:
 
 * Add the digits (up to but not including the check digit) in the odd‐numbered positions (first, third, fifth, etc.).
 * Add the digits (up to but not including the check digit) in the even‐numbered positions (second, fourth, sixth, etc.) together and multiply by three. Then add this onto to the result.
 * Take the remainder of the result divided by 10 (modulo operation) and subtract this from 10 to derive the check digit.

 You can see an example at [http://www.gs1.org/how-calculate-check-digit-manually](http://www.gs1.org/how-calculate-check-digit-manually). You can also calculate a UPC check digit using the calculator at [http://www.gs1.org/check-digit-calculator](http://www.gs1.org/check-digit-calculator). Note, only enter the first 12 digits of the UPC, do not enter the last digit (which is the check digit, as the calculator will calculate it for you...and you can then check if it's correct).
 
 For instance, the UPC barcode for a book is `9780984782857`. The last digit is the check digit `7`, and if the other numbers are correct then the check digit calculation must produce `7`.
 
 * Add the odd number digits: `9 + 8 + 9 + 4 + 8 + 8 = 46`
 * Add the even number digits: `7 + 0 + 8 + 7 + 2 + 5 = 29`
 * Multiply the result by `3`: `29 × 3 = 87`
 * Add the two results together: `46 + 87 = 133`
 * To derive the check digit, calculate the remainder of `133 / 10`, which is also known as `133 modulo 10`. In this example, the remainder is `3`. Subtract the remainder from `10` to get the check digit. In this example, the result and check digit is `7`.
 
 You need to design and implement a function which will take a single string parameter called `upc` (which is the entire 13-digit UPC of a product) and return a Boolean `true` or `false` value depending on whether the provided code is valid or invalid.
 */

func validateUPC(upc: String) -> Bool {

    // Change this depending on whether the code is valid or invalid
    return false
    
}

let testUPC = ""

// Your code goes here

//: ---
//: [Previous](@previous) | [Next](@next)
