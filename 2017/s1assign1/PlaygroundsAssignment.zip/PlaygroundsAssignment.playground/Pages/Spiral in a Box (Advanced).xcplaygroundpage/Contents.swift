/*:
 
 # Year 10 IST - Assignment One
 
 ### Spiral in a Box (Advanced)
 
 Write a program which will print, to the console, a spiral inside of a box based upon a size specified in the `size` constant.
 
 For example, if the `size` is `4` then this should be printed:
 
 ![Spiral Size 4](spiral4.png)
 
 ...or if the `size` is `5` then this should be printed:
 
  ![Spiral Size 5](spiral5.png)
 
 The above are just examples – your program should be able to print any sized box (we will be varying the box size when testing your program to ensure that it works correctly). However, you can assume that the input size for the box will always be greater than 1.

 A sample project, allowing you to see a working example, is available at: [http://www.cgscomputing.com/year10/spiral/sample.php?size=5](http://www.cgscomputing.com/year10/spiral/sample.php?size=5) (change the `size` argument to see different sized spirals). This will be very useful so you can check that the spirals you are drawing are correct.
 
If an invalid value is entered for the size (i.e. not a number greater than 1) then nothing should print.
*/

let size = 5;

// Your code goes here

//: ---
//: [Previous](@previous) | [Next](@next)