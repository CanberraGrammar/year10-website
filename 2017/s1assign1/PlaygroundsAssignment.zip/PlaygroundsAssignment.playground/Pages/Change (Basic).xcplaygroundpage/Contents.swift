/*:
 
 # Year 10 IST - Assignment One
 
 ### Change (Basic)
 
 You need to develop a program which determines the amount of change for a purchase, given a purchase amount and an amount of cash tendered.
 
 There are two constants to hold these pieces of data: `purchaseAmount` and `cashTendered`.
 
 The output of the program should be the number of Australian coins and bills that need to be given to the customer for the change. Valid denominations in coins are 5 cents, 10 cents, 20 cents, 50 cents, $1, and $2. The valid denominations in bills are $5, $10, $20, $50, $100.
 
 For example, the output for `purchaseAmount` = `11.55` and `cashTendered` = `20.00` would be:
 
 ````
 $100 x 0
 $50 x 0
 $20 x 0
 $10 x 0
 $5 x 1
 $2 x 1
 $1 x 1
 $0.50 x 0
 $0.20 x 2
 $0.10 x 0
 $0.05 x 1
 
 ````
 
 ...which provides the required $8.45 of change.
 
 The program should always dispense the least quantity of money to make up the required amount of change. For example, it should dispense 1x $2 coins rather than 2x $1 coins.

 The program should print the message "Insufficient cash tendered" if the `purchaseAmount` is greater than the `cashTendered` amount.
 
 You don't need to worry about handling invalid inputs (e.g. `4a.38`). You can assume that a valid amount of money will always be input into the program.
 
 Additionally, all amounts are a multiple of 5 cents (e.g. $19.95).
 
 */

// Be sure to test with other values too!
let purchaseAmount = 11.55
let cashTendered = 20.00

// Your code goes here

//: ---
//: [Previous](@previous) | [Next](@next)
