/*:
 
 # Year 10 IST - Assignment One
 
 ### Hash Cracker (Advanced)
 
 When passwords are stored in databases (for online services such as Yahoo, Facebook, Twitter, and even the school email server) they are stored as a one-way hash. This is essentially an encrypted version of the password, which cannot be reversed (i.e. it's a one-way encryption). When you login to the service, the password that you enter is hashed using the exact same method, and then that hash is compared to the hash of the password stored in the database. If the two hashes match, you are granted access. If they do not match, you are denied access.
 
 If you have ever forgotten your password you might wonder why technical support cannot tell you your password...and the reason is that they cannot see your password - but they can reset your password by setting a new password, hashing that new password, and then storing that in the database overwriting the old hash.
 
 If someone manages to compromise the database it is possible for them to have access to the hash of your password. While that will not tell them your password (as it's hashed) it is possible that they can brute-force your password, particuarly if it's a weak password. This involves creating a hash of common passwords, comparing the generated hash to the hash of your password, and checking if they match. If they do, because they know what plain-text version corresponds to each hash, they can determine your password. This is why it's important to have strong passwords.
 
 For example, if you compromised a database and obtained a list of usernames and their associated hashed passwords it might look like this:
 
 ````
 michael / 4660a428ce37fbdcb71a6a06a2ad9288
 liam / f7a43294cbaa09a57bcc9f303c44e754
 ben / b48393bc46907ce819eb73c8a0147e34
 james / 0456c1d8d3d2d22a750de103ec1f7902
 alex / 5d2c4ebe7e349356ddede3189218fe99
 `````
 
 You need to design and implement a function which can crack hashed passwords. You can assume that:
 
 * The function takes a single parameter `hashedPassword` and returns the plain-text of that hash.
 
 * Each password is exactly four characters (shudder!).
 
 * Each password only contains lowercase alphabetical characters `a - z` (double shudder!).
 
 Your program should brute-force the password, so it will need to dynamically generate all combinations of four letter passwords.
 
 To hash a string, call the `.hash. function on the string. For example:
 
 `"test".hash`
 
 returns:
 
 `2229efa0ec05e098fb0bf9e400100640`
 
 */

func crackHash(_ hashedPassword: String) -> String {
    
    // Change this to return the plain-text password
    return ""
    
}

print(crackHash("test"))

//: ---
//: [Previous](@previous)
