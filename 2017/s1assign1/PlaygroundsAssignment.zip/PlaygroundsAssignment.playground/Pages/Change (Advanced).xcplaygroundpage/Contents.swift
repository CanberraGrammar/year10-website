/*:
 
 # Year 10 IST - Assignment One
 
 ### Change (Advanced)
 
 You need to develop a program which determines the amount of change for a purchase, given a purchase amount and an amount of cash tendered.
 
 There are two constants to hold these pieces of data: `purchaseAmount` and `cashTendered`.
 
 However, this program is being used in a country called Nailartsua which has quite a strange (and somewhat arbitrary) denomination of currency. Valid denominations in coins are 1 cent, 15 cents, and 25 cents. The valid denominations in bills are $10, $30, and $40.
 
 The output of the program should be the number of Nailartsua coins and bills that need to be given to the customer for the change.
 
 For example, the output for `purchaseAmount` = `19.70` and `cashTendered` = `20.00` would be:
 
 ````
 $40 x 0
 $20 x 0
 $10 x 0
 $0.25 x 0
 $0.15 x 2
 $0.01 x 0
 ````
 
 The program should always dispense the least quantity of money to make up the required amount of change. For example, it should dispense 1x $20 note rather than 2x $10 notes.
 
 The program should print the message "Insufficient cash tendered" if the `purchaseAmount` is greater than the `cashTendered` amount.
 
 You don't need to worry about handling invalid inputs (e.g. `4a.38`). You can assume that a valid amount of money will always be input into the program.
 
 **Tip:** Test your algorithm for change amounts like $60.30. Your algorithm might determine the change as `1x $40, 2x $10, 1x $0.25, 5x $0.01` whereas the optimal solution is `2x $30, 2x $0.15`.
 
 */

// Be sure to test with other values too!
let purchaseAmount = 19.70
let cashTendered = 20.00

// Your code goes here

//: ---
//: [Previous](@previous) | [Next](@next)
