/*:
 
 # Year 10 IST - Assignment One
 
 ### Mario Pyramid (Basic)
 
 In Nintendo’s Super Mario Brothers, Mario needs to climb a half-pyramid to jump and reach a flag pole - as shown in this screenshot:
 
 ![Mario Half-Pyramid](mario.png)
 
 Write a program which will print, to the console, a half-pyramid of the heigh specified in the `height` constant.
 
 For example, if the `height` is equal to `5` then this should be printed:
 
 ````
     ##
    ###
   ####
  #####
 ######
 ````
 The height of the half-pyramid in the screenshot above is 8.
 
 You can assume that the value of `height` will always be a value >= `1`.
 */

let height = 5;

// Your code goes here