//
//  GameViewController.swift
//  TicTacToe
//

//
// This project is submitted as part of the assessment for Year 10 IST.
// This is all my own work. I have referenced any work used from other
// sources and have not plagiarised the work of others.
// (signed) Name Here
//

import UIKit

class GameViewController: UIViewController {
    
    // IBOutlets
    @IBOutlet weak var buttonZero: UIButton!
    @IBOutlet weak var buttonOne: UIButton!
    @IBOutlet weak var buttonTwo: UIButton!
    @IBOutlet weak var buttonThree: UIButton!
    @IBOutlet weak var buttonFour: UIButton!
    @IBOutlet weak var buttonFive: UIButton!
    @IBOutlet weak var buttonSix: UIButton!
    @IBOutlet weak var buttonSeven: UIButton!
    @IBOutlet weak var buttonEight: UIButton!
    @IBOutlet weak var playGameButton: UIButton!
    @IBOutlet weak var turnLabel: UILabel!
    
    // Create an instance variable to store an array of all the buttons
    var buttonArray: [UIButton] = []
    
    // Called after the view controller has loaded its view hierarchy into memory
    override func viewDidLoad() {
        
        // Call super
        super.viewDidLoad()
        
        // Put all the buttons into the button Array
        buttonArray = [buttonZero, buttonOne, buttonTwo, buttonThree, buttonFour, buttonFive, buttonSix, buttonSeven, buttonEight]
        
        // Loop through each button and set a border
        for button in buttonArray {
            button.layer.borderColor = UIColor.lightGray.cgColor
            button.layer.borderWidth = 0.5
        }
        
        // Set the scaling mode on the button image
        playGameButton.imageView?.contentMode = .scaleAspectFit
        
    }
    
}
